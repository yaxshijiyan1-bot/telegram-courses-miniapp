# Examples

## Mundarija

1. Exact recreation misoli
2. Original concept misoli
3. Preserve-and-customize misoli
4. Yaxshi va zaif motion instruction taqqoslash
5. Anti-patternlar

## 1. Exact recreation misoli

```markdown
# Exact recreation prompt — Aster Intelligence

Recreate this page pixel-faithfully from the supplied reference. Use React + TypeScript + Vite + Tailwind CSS + Framer Motion + lucide-react. Do not invent alternate copy, layout, fonts, colors, or effects.

## Page identity
- Dark editorial AI consultancy landing page.
- Full-viewport abstract video is visual context, not a clickable background.
- White typography, restrained glass chips, sparse composition.
- Avoid purple gradients, generic icon-card grids, stock dashboard illustrations and extra sections.

## Assets
- Use `/assets/aster-hero.mp4` as the scroll-scrubbed hero media.
- Use `/assets/aster-poster.jpg` until the first decoded frame is ready.
- Use `/assets/aster-mark.svg` as the brand mark; do not redraw it.
- All nondecorative images require meaningful alt text.

## Interaction and motion
- Keep the hero media fixed behind the content.
- Map page scroll progress from 0 to 1 to the video timeline with clamping and 0.12 lerp smoothing.
- Reveal label, headline, supporting copy and CTA with `translateY(2rem) opacity:0` to `translateY(0) opacity:1`, 700ms ease-out, threshold 0.15.
- With reduced motion, show the poster and fully readable final content without continuous animation.

## Acceptance criteria
- The hero composition, asset crop, typography hierarchy and CTA placement match the reference.
- No horizontal overflow exists at 375px, 768px, 1024px or 1440px.
- Video failure leaves a usable poster and content remains accessible.
```

## 2. Original concept misoli

```markdown
# Original concept prompt — Lumen Field Notes

Use the reference only as direction for a dark editorial layout, pinned media and scroll-based scene change. Create an original brand and do not copy the reference’s copy, logo, distinctive asset or proprietary illustration.

Build a React + TypeScript + Vite + Tailwind CSS site for a climate research studio. The hero should move from an abstract satellite image to a field-note interface as the user scrolls. Use a warm amber accent, off-white typography and a restrained glass material. The primary CTA is `Read the field notes`.

Define the exact scene timeline, section order, mobile fallback, keyboard behavior and acceptance criteria. Use original placeholder tokens for missing research copy instead of invented claims.
```

Bu misolda reference’dan “dark editorial layout + pinned media + scroll scene change” kabi prinsiplar olingan, lekin brand, copy va assetlar yangi.

## 3. Preserve-and-customize misoli

```markdown
Keep the existing layout, typography, colors, material system, animation timing, responsive behavior and component hierarchy exactly as they are. Rewrite only the content for `Navo Robotics`.

Replace the brand wordmark, headline, services, testimonial, portrait and CTA URL using the mapping below. Do not add new cards, gradients, sections or effects. Do not change the hero video, nav geometry, headline scale or reveal delays.

Brand: `DE/HELPERS` → `NAVO ROBOTICS`
Headline: `Outsourced development team` → `Robotics for safer factories`
CTA: `Hire us` → `Book a factory audit`

After generating the complete version, make only one refinement: reduce mobile hero top padding by 8px. Verify at 375px and 1440px.
```

## 4. Motion instruction taqqoslash

| Zaif | Kuchli |
|---|---|
| “Make the hero cinematic and smooth.” | “Keep the media fixed; map clamped scroll progress to frame index; lerp by 0.12; use poster → video → canvas fallback; disable continuous motion for reduced motion.” |
| “Add a cool glass navbar.” | “Use `bg-white/15 backdrop-blur-md`, `border-white/15`, fixed `z-50`, visible focus ring, desktop links and mobile overlay with Escape close.” |
| “Animate the text on scroll.” | “At IntersectionObserver threshold 0.15, transition `translateY(2rem) opacity:0` to `translateY(0) opacity:1` over 700ms ease-out; delay heading 280ms and CTA 500ms.” |
| “Make it responsive.” | “At 375px stack the hero, hide desktop links, show a keyboard-accessible hamburger, reduce H1 to 3rem, preserve CTA visibility and remove horizontal overflow.” |

## 5. Anti-patternlar

- Faqat mood adjectives yozish: “luxury, futuristic, premium, amazing.” Ularni token, layout va behavior’ga aylantir.
- “Use a similar website” deyish: reference qaysi tamoyil uchun ishlatilishini ajrat.
- Exact copy noma’lum paytda random marketing claim yoki metric o‘ylab topish.
- Asset URL’ni bermasdan “add a 3D object” deyish.
- Mobile va reduced-motion holatini keyinga qoldirish.
- Birinchi v1 tugamasdan o‘nlab micro-change yuborish.
- Har bir elementga boshqa animation va gradient qo‘shib, yagona design systemni buzish.
