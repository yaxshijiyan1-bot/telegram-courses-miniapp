# MotionSites AI — tadqiqot qaydlari

## Manba va tekshiruv sanasi
- Asosiy manba: https://motionsites.ai/
- Tekshiruv vaqti: 2026-08-15 (foydalanuvchi sessiyasi timezone kontekstida).
- Browser orqali bosh sahifa va `?prompt=orbit-flora` prompt tafsilot ko‘rinishi ochildi; HTML snapshot’lar `/home/ubuntu/upload/` ichida saqlandi.

## Bosh sahifa kuzatuvlari
- Title: `MotionSites AI — Official Premium AI Website Prompts`.
- Meta description: `Beautiful Website Prompts for Lovable, Bolt, Cursor, and Claude. Build Stunning 3d Websites With AI. Just copy, paste, and launch`.
- Value proposition: “Build beautiful landing pages in minutes with our ready-to-use prompts. Just copy, paste, and launch.”
- Katalog bo‘limlari: All, Apps, Sections; filter/category’lar orasida Hero, Landing Page, Saas, Agency, Portfolio, 3d Website, Travel, Ecommerce, Wellness, Ai, Carousel, Fintech, Technology, Fashion, Healthcare; sorting/filter: Popular, Pricing.
- Navigatsiya: MCP, Request a Prompt, Animated Backgrounds, Academy, Submit Design, Contact, Sign up, Go Unlimited.
- Katalog card’lari preview image/video, nomi va kategoriya bilan ko‘rsatiladi; karta bosilganda URL query ko‘rinishi `/?prompt=orbit-flora` bo‘lib, alohida dialog/detail layout ochildi.
- Qo‘shimcha qiymat: animated backgrounds, Academy/DesignRocket cross-promotion, full library CTA.

## Orbit Flora detail kuzatuvi
- Detail ko‘rinishda Orbit Flora / AI, like count (18), “Copy full prompt” tugmasi va preview ko‘rinadi.
- Browser orqali “Copy full prompt” bosilganda UI `Copied` holatiga o‘tdi; page source’da prompt matni DOM’da ko‘rinmadi, matn clipboard API orqali olinadi.
- Related/project catalog bloklari ko‘rsatiladi: Projects Catalog, Intelligent Systems, SaaS, AI Workflow Agents, Mountain Retreat, AI Companions, Augmented Sight, Bitcoin Yield, Tech-Noir About, Imperial VPN, AI Runtime, Frontier, Automation Machines, Cyber Layer, Breathstone, Data Signal, Mouse Trail CTA, Nike Hover, DeepThink, Real-Time Alerts, Form Study, Cardia 3D.

## Front-end kodidan aniqlangan prompt access modeli
- `PromptCard` komponenti `get-prompt` serverless function’iga `{prompt_id: e.id}` body bilan murojaat qiladi va javobdan `prompt_text` hamda `asset_download_url` oladi.
- Auth session access token mavjud bo‘lsa Authorization header yuboriladi; access denied holatida “This prompt is part of Unlimited Access.” xabari ishlatiladi.
- Card-level `hasAccess` uchun `e.is_free` true bo‘lsa prompt bepul ochiladi; aks holda authenticated/premium/pack credits qoidalari ishlaydi.
- Free bo‘lmagan foydalanuvchi uchun prompt unlock icon `Go Unlimited` oqimiga olib boradi. Free promptlar esa copy limit bilan boshqariladi: kodda authenticated bo‘lmagan user uchun kunlik limit 3, authenticated user uchun 6 sifatida ko‘rinadi.
- Bepul account like qilish uchun kerak; like funksiyasi sign-in talab qiladi.
- Prompt copy qilinganda “Prompt copied. Paste it into your AI builder and generate your site.” banneri chiqadi.
- Asset download alohida `get-prompt` javobidagi `asset_download_url` orqali amalga oshadi.

## Client/catalog kodidan ko‘ringan metadata maydonlari
- Prompt record maydonlari: `id`, `title`, `category`, `type`, `is_free`, `has_assets`, `image_preview_url`, `video_preview_url`, `row_span`, `page_type`, `natural_ratio`; ayrim promptlarda `boltUrl`, `githubUrl`, `googleAiStudioUrl`, `kimiUrl` kabi remix/source linklar bo‘lishi mumkin.
- Detail related prompt query `design_similarity` / RPC `get_design_similar_prompts` orqali related ID’larni topadi va `prompts` jadvalidan metadata oladi.
- Analytics/signal qatlamida `open`, `copy`, `like` kabi event’lar va `is_free`, `is_authed`, `is_featured`, `position`, `surface` konteksti yoziladi.

## Bundle’da ko‘ringan bepul prompt misollari
- `Digital Epoch` — Hero Section — free.
- `Velorah Focus` — Social Media — free.
- `RIVR` — Hero Section — free.
- `Lumina` — Footer Section — free.
- `HAUL!` — Footer Section — free.
- `Vize Footer` — Footer Section — free.
- `Glow Features` — Features Section — free.
- Bundle’da bepul bo‘lishi ko‘ringan ayrim boshqa ID’lar ham bor; to‘liq katalogni alohida extraction bilan chiqarish kerak.

## Ishchi metodik xulosa
MotionSites prompt mahsuloti faqat “matn” emas: u visual preview + prompt copy + category/filter metadata + asset/remix link + related designs + access tier kombinatsiyasidir. Promptlarni tahlil qilishda alohida: (1) sahifa maqsadi, (2) visual direction, (3) layout/sections, (4) motion/interaction, (5) typography/color, (6) responsive/accessibility, (7) technical implementation, (8) content/CTA, (9) assets, (10) verification/remix instructions qatlamlari ajratilishi kerak.

## Keyingi tekshiruvlar
1. Main bundle’dan `prompts` jadvali query’lari va catalog fetch oqimini ajratish.
2. Free promptlarning detail/copy tajribasini kamida 2–3 misolda tekshirish.
3. Academy/Request a Prompt/Animated Backgrounds sahifalarini o‘rganish.
4. Prompt namunalari ochiq text bilan mavjud bo‘lsa, tarkibiy patternlarni datasetga aylantirish; aks holda UI va koddan infer qilingan generic prompt framework’ni yaratish.

## Academy kuzatuvlari
Academy title: `Academy — Learn Cinematic 3D AI Websites | MotionSites`. Sahifa o‘zini “Free video tutorials on prompting, animation and 3D — go from idea to shipped site” deb ta’riflaydi. Featured Build oqimi: walkthrough’ni ko‘rish, keyin videoda ishlatilgan promptni copy qilish. Ko‘rsatilgan tutorial mavzulari scroll-animated website, animated website, premium animated website, Claude/Fable 5 bilan web design va Grok 4.5 scroll website qurish atrofida. Bu MotionSites metodikasida prompt + animation + 3D + video walkthrough + copy/remix iteratsiyasi birgalikda o‘qitilishini ko‘rsatadi.

## Academy darsidagi prompt patternlari
`How to Build a Scroll-Animated Website With AI` darsida promptning ochiq namunasi berilgan. Namuna `# Exact recreation prompt — NovaAI landing page` sarlavhasi bilan boshlanadi va “Recreate this page pixel-faithfully” deb qat’iy fidelity talabini qo‘yadi. Stack aniq ko‘rsatiladi: React + TypeScript + Vite + Tailwind CSS + lucide-react; “Do not invent alternate copy, layout, fonts, colors, or effects.” deyiladi.

Prompt keyin qatlamlarga ajraladi: Page identity (title, brand, overall feel, anti-directions); Assets (exact URLs, video content description, dimensions, local fallback, portrait asset, display size and alt); Fonts and global tokens; Global structure (fixed scroll video layer, wrapper, navbar, sections, spacer); Scroll-scrubbed video behavior (poster/video/canvas layers, progress formula, lerp smoothing, frame cache, fallback seeking, canvas DPR, autoplay restriction); Reveal animation (IntersectionObserver threshold, hidden/visible states, duration, delays); Glass/material token system (panel, border, badge, CTA, text-over-video, mono labels); Navbar; Section One hero with service list, intro, badge, H1 and CTA. Tool/implementation instructions are expressed as exact behavior and class/token values, not only adjectives.

Darsning oldingi 3D lesson’ida ham prompt chunk’lari bor: “Create a website where the page doesn’t scroll — everything is pinned on screen, and scrolling drives the animation from scene one to scene two. Scene one: a giant bold headline. Scene two: a second headline. On scroll, the headline letters scatter and fly upward.” Keyingi qo‘shimcha prompt: “Use this GLB file and animate it in the website as shown in the reference video. Implement it with Three.js.” Muayyan fontlar (Passion One headlines, Inter body) va tone mapping fix’i ham beriladi.

Bu darslar promptni ikki bosqichli qilishni ko‘rsatadi: avval visual direction/reference/assets, keyin AI coding tool ichida implementation prompt; promptda visual niyat bilan birga deterministic technical acceptance criteria beriladi.

## Animated website darsi
`How to Build an Animated Website with AI and MotionSites` promptni qisqa vazifa jumlasidan boshlab, keyin `SETUP`, `LIQUID GLASS CSS`, `PAGE STRUCTURE`, `BACKGROUND VIDEO`, `NAV`, `HERO CONTENT`, `DEPENDENCIES` bo‘limlariga ajratadi. Misol stack: React + TypeScript + Vite + Tailwind + Framer Motion + lucide-react. Setup’da exact external font URL, page title, reset CSS, body background/color/antialiasing/selection beriladi. Liquid glass effekti uchun CSS pseudo-elementlari, gradients, backdrop blur, saturation, border mask va pointer-events aniq yoziladi.

Page structure’da sticky background video va `-mt-[100vh]` content overlay kabi layout mexanikasi, exact video URL, overlay gradient, fixed nav, desktop/mobile nav variantlari, AnimatePresence bilan menu open/close transitions, stagger delay’lar, hero grid va exact copy/assets beriladi. Dependency’lar alohida sanaladi. Darsdagi customization bosqichi “existing designni saqlab, faqat business contentini almashtir” qoidasini beradi; refine bosqichi esa bir o‘zgarishni bir vaqtda qilishni tavsiya qiladi: mobile spacing, overlay, headline size va hokazo.

Bu pattern MotionSites promptlarida ikki muhim narsani ko‘rsatadi: design intent’ni o‘zgartirmaslik uchun preservation constraints va kod generatorini ortiqcha ijodiy taxmindan qaytarish uchun explicit constraints; shuningdek promptni avval to‘liq birinchi versiyani generatsiya qilish, keyin incremental refinement oqimiga qo‘yish.

## Premium animated lesson’dan qo‘shimcha qoidalar
MotionSites o‘z promptlarini layout, styling, fonts, animations, responsive behavior, dependencies va exact content’ni bir paketga yig‘uvchi recreation specification sifatida ta’riflaydi. Promptlar React + TypeScript + Tailwind CSS + Framer Motion uchun yo‘naltirilgan. Desktop, tablet va mobile ko‘rsatmalar promptning ichida bo‘lsa ham, har bir screen size’da test qilish kerak. AI’ga butun sahifani qayta redesign qildirishdan ko‘ra kichik va aniq instruction’lar yaxshiroq ishlashi aytiladi. Default workflow: design tanlash → prompt copy qilish → AI builderga joylash → natijani refine qilish.
