# Quality checklist

## Mundarija

1. Prompt preflight
2. Visual QA
3. Interaction QA
4. Responsive/accessibility QA
5. Performance QA
6. Refinement protocol
7. Scoring rubric

## 1. Prompt preflight

Promptni yuborishdan oldin quyidagi savollarga aniq javob bo‘lishi kerak:

| Tekshiruv | Ha bo‘lishi kerak |
|---|---|
| Maqsad | Sahifa kim uchun va CTA nima ekani aniq |
| Rejim | Recreation, original yoki customization tanlangan |
| Stack | Framework va dependency’lar ko‘rsatilgan |
| Assets | URL/path, role, fallback, dimensions, alt bor |
| Tokens | Font, rang, spacing, radius, blur va shadow qiymatlari bor |
| Structure | Layer, section order, z-index va viewport behavior bor |
| Motion | Trigger, state, timing, mapping va fallback bor |
| Responsive | Desktop, tablet, mobile o‘zgarishlari bor |
| Accessibility | Semantics, keyboard, focus, alt va reduced-motion bor |
| Acceptance | Tayyorlik mezonlari tekshiriladigan gaplarda yozilgan |

## 2. Visual QA

Rendered sahifani reference yoki brief bilan solishtir. Birinchi navbatda hierarchy, viewport composition, headline scale, whitespace, media crop, contrast va CTA position’ni tekshir. Keyin border radius, blur, shadow, icon size va micro-spacing’ga o‘t. “Chiroyli” degan hukmni o‘lchanadigan kuzatuvga aylantir: “Hero heading mobile’da 2 qatordan 4 qatorga tushib, CTA’ni viewportdan chiqarib yubordi.”

## 3. Interaction QA

Har bir triggerni alohida sinab ko‘r: scroll progress boshida/o‘rtasida/oxirida, hover, click, drag, menu open/close, Escape, outside click va CTA route. Video frame, canvas, poster va error fallback’lar ham tekshirilsin. Animatsiya birinchi load’da chala holatda qolmasin va tez scroll qilganda progress orqada qolib ketmasin.

## 4. Responsive va accessibility QA

Kamida 375px mobile, 768px tablet, 1024px laptop va 1440px desktop kengliklarida tekshir. Overflow, horizontal scroll, fixed nav collision, mobile menu focus, heading order, link/button semantics, visible focus ring, keyboard order, alt text, color contrast va reduced-motion holatini sinab ko‘r. Touch qurilmada hover’ga bog‘langan kritik behavior bo‘lmasin.

## 5. Performance QA

Network sekin bo‘lganda poster yoki skeleton darhol ko‘rinsin. Hero media lazy-load qoidalariga zid bo‘lmasin; critical asset preload qilinsin. Video frame cache uchun max width/frame count, 3D uchun texture resolution va DPR cap qo‘yilsin. Event listener, animation loop, object URL, ImageBitmap, WebGL resource va observer cleanup qilinsin. Browser console’da error va warning qolmasin.

## 6. Refinement protocol

Refinementni quyidagi formatda yoz:

```text
Observed: [aniq ko‘ringan muammo]
Cause: [layout, token, timing, asset yoki state sababi]
One change: [faqat bitta o‘zgarish]
Preserve: [o‘zgarmasligi kerak bo‘lgan tizim]
Verify: [qaysi viewport/interaction’da qayta tekshiriladi]
```

Misol:

```text
Observed: Mobile’da CTA fixed navbar ostida yashirinmoqda.
Cause: Hero `pt-24` qiymati navbar balandligidan kichik.
One change: Mobile’da `pt-32` qilib, desktop qiymatlarini o‘zgartirma.
Preserve: Font, color, animation timing va desktop layout.
Verify: 375px viewport’da initial load va scroll top holatini tekshir.
```

Butun promptni qayta yozishdan yoki “make it more premium” deyishdan qoch. Bitta muammo, bitta sabab, bitta o‘zgarish — eng barqaror iteration usuli.

## 7. Scoring rubric

Har bir qatlamga 0–2 ball ber: `0` — yo‘q; `1` — umumiy; `2` — aniq va test qilinadi.

| Qatlam | Savol |
|---|---|
| Identity | Visual direction va anti-directions aniqmi? |
| Assets | Assetlar va fallback’lar aniqmi? |
| Stack | Builder/framework/dependency aniqmi? |
| Tokens | Rang, font, spacing va material tokenlari bormi? |
| Structure | Layer va section geometry aniqmi? |
| Motion | Trigger/state/timing/mapping yozilganmi? |
| Content | Exact copy yoki placeholder qoidasi bormi? |
| Responsive | Breakpoint va mobile simplification bormi? |
| Accessibility | Keyboard/focus/alt/reduced-motion bormi? |
| Acceptance | Natija qanday tekshirilishi yozilganmi? |

16/20 dan past promptni yuborma; eng past ball olgan qatlamni avval to‘ldir.
