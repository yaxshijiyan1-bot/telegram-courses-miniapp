from bs4 import BeautifulSoup
from pathlib import Path
import json, re

html_path = Path('/home/ubuntu/upload/motionsites.ai__1786798404316.html')
html = html_path.read_text(errors='ignore')
soup = BeautifulSoup(html, 'html.parser')

out = []
for a in soup.find_all('a'):
    href = a.get('href')
    txt = ' '.join(a.get_text(' ', strip=True).split())
    if href or txt:
        out.append({'tag':'a','text':txt[:300], 'href':href})

for script in soup.find_all('script'):
    src = script.get('src')
    text = script.string or script.get_text()
    if src:
        out.append({'tag':'script','src':src})
    if text and any(k in text.lower() for k in ['prompt','api/','supabase','firebase','orbit flora','oyla']):
        out.append({'tag':'script-inline','text':text[:2000]})

# Extract all URL-like strings that may reveal route/data endpoints
urls = sorted(set(re.findall(r'https?://[^\"\'\\\s<>]+|/[A-Za-z0-9_./?=&%-]{2,}', html)))
Path('/home/ubuntu/motionsites_links.json').write_text(json.dumps({'links':out,'url_like':urls}, ensure_ascii=False, indent=2))
print(json.dumps({'html_chars':len(html),'links':len(out),'url_like':len(urls)}, indent=2))
print('\n'.join(json.dumps(x, ensure_ascii=False) for x in out[:80]))
print('\nURL-LIKE SAMPLE')
print('\n'.join(urls[:120]))
