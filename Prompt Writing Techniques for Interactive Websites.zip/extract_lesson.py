from bs4 import BeautifulSoup
from pathlib import Path
import re

p=next(Path('/home/ubuntu/upload').glob('motionsites.ai_lesson_build-scroll-animated-website-with-ai_*.html'))
soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
for x in soup(['script','style','noscript','svg']): x.decompose()
# print all text-containing pre/code and likely prompt containers
out=[]
for tag in soup.find_all(['pre','code','article','main','section','div']):
    text='\n'.join(line.strip() for line in tag.get_text('\n',strip=True).splitlines() if line.strip())
    if len(text)>200 and any(k.lower() in text.lower() for k in ['exact recreation prompt','page identity','scroll-scrubbed video','nova_ai','section one']):
        out.append((tag.name, tag.get('class'), len(text), text))
# dedupe by text and prefer shortest containing block
seen=set(); rows=[]
for name,cls,l,text in sorted(out,key=lambda x:x[2]):
    if text in seen: continue
    seen.add(text); rows.append((name,cls,l,text))
Path('/home/ubuntu/lesson_prompt_blocks.txt').write_text('\n\n'.join(f'### {name} class={cls} chars={l}\n{text}' for name,cls,l,text in rows), encoding='utf-8')
print('blocks',len(rows))
for name,cls,l,text in rows[:5]:
    print('###',name,cls,'chars=',l)
    print(text[:5000])
    print('\n---END SAMPLE---\n')
