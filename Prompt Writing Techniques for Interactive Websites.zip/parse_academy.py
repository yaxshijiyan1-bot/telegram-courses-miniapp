from bs4 import BeautifulSoup
from pathlib import Path
import json

p=Path('/home/ubuntu/upload/motionsites.ai_academy_1786798802187.html')
soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
rows=[]
for tag in soup.find_all(['a','video','source','iframe','script']):
    row={'tag':tag.name}
    for attr in ['href','src','data-src','poster','title','aria-label']:
        if tag.get(attr): row[attr]=tag.get(attr)
    txt=' '.join(tag.get_text(' ',strip=True).split())
    if txt: row['text']=txt[:500]
    if len(row)>1: rows.append(row)
Path('/home/ubuntu/academy_links.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print(json.dumps(rows,ensure_ascii=False,indent=2))
