from pathlib import Path
import re

for fname in ['/home/ubuntu/motionsites_assets/dist-cgp.js','/home/ubuntu/motionsites_assets/PromptDetailDialog.js','/home/ubuntu/motionsites_assets/client.js']:
    s=Path(fname).read_text(errors='ignore')
    print('\n###',Path(fname).name,'chars=',len(s))
    for term in ['is_free','isFree','free','prompt_text','get-prompt','createClient','supabaseUrl','anonKey','image_preview_url','video_preview_url']:
        print('TERM',term,'COUNT',s.count(term))
        pos=0; shown=0
        while shown<8:
            pos=s.find(term,pos)
            if pos<0: break
            start=max(0,pos-500); end=min(len(s),pos+1200)
            print('---',term,'at',pos,'---')
            print(s[start:end])
            pos += len(term); shown+=1
