from bs4 import BeautifulSoup
from pathlib import Path
import json, re

path = Path('/home/ubuntu/upload/motionsites.ai__prompt_orbit-flora_1786798673670.html')
html = path.read_text(errors='ignore')
soup = BeautifulSoup(html, 'html.parser')

# Keep meaningful visible text with repeated whitespace normalized.
text = '\n'.join(line.strip() for line in soup.get_text('\n').splitlines() if line.strip())
Path('/home/ubuntu/orbit_flora_visible_text.txt').write_text(text)

meta = []
for tag in soup.find_all(['meta','title','link']):
    row = {'tag': tag.name}
    for key in ['name','property','content','href','rel','canonical']:
        if tag.get(key) is not None:
            row[key] = tag.get(key)
    if len(row) > 1:
        meta.append(row)

# Look for likely prompt-bearing serialized data in scripts and raw HTML.
keywords = ['orbit flora','copy full prompt','prompt','description','isfree','is_free','prompttext','fullprompt','unlock']
chunks=[]
for m in re.finditer(r'.{0,500}(?:'+'|'.join(map(re.escape,keywords))+r').{0,1500}', html, flags=re.I|re.S):
    s = re.sub(r'\s+', ' ', m.group(0))
    chunks.append(s[:2200])
chunks = list(dict.fromkeys(chunks))

# Print structured overview.
print('HTML_CHARS', len(html))
print('VISIBLE_TEXT_FILE', '/home/ubuntu/orbit_flora_visible_text.txt')
print('META')
print(json.dumps(meta, ensure_ascii=False, indent=2)[:12000])
print('KEYWORD_CHUNKS', len(chunks))
for i,c in enumerate(chunks[:80],1):
    print(f'---CHUNK {i}---')
    print(c)
